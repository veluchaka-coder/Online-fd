# Tasty Bites – Online Food Ordering Website
Hackathon Level 2 – Fundamentals of Web Development

## Run
Open `index.html` in any modern browser (no server or installation needed).

## Structure
- index.html – page structure
- css/style.css – styling and responsive layout
- js/data.js – menu data
- js/script.js – filter, search, cart, validation, Local Storage
- images/ – food images (SVG)
