// ===== State =====
const CART_KEY = "tastyBitesCart";
const GST_RATE = 0.05;
let cart = loadCart();          // { itemId: quantity }
let activeCategory = "All";
let searchText = "";

// ===== DOM references =====
const $ = (id) => document.getElementById(id);
const foodGrid = $("foodGrid"), filters = $("categoryFilters"), noResults = $("noResults");
const cartItemsEl = $("cartItems"), emptyCart = $("emptyCart"), orderSummary = $("orderSummary");
const orderForm = $("orderForm"), cartPanel = $("cartPanel"), cartCount = $("cartCount");

const money = (n) => "₹" + n.toFixed(2);
const findItem = (id) => FOOD_ITEMS.find((f) => f.id === Number(id));

// ===== Local Storage =====
function loadCart() {
  try {
    const saved = JSON.parse(localStorage.getItem(CART_KEY)) || {};
    Object.keys(saved).forEach((id) => {
      if (!FOOD_ITEMS.some((f) => f.id === Number(id)) || !(saved[id] > 0)) delete saved[id];
    });
    return saved;
  } catch (e) { return {}; }
}
function saveCart() {
  try { localStorage.setItem(CART_KEY, JSON.stringify(cart)); } catch (e) { /* storage unavailable */ }
}

// ===== Menu rendering, filter and search =====
function renderFilters() {
  const cats = ["All", ...new Set(FOOD_ITEMS.map((f) => f.category))];
  filters.innerHTML = cats.map((c) =>
    `<button class="filter-btn ${c === activeCategory ? "active" : ""}" data-cat="${c}">${c}</button>`).join("");
}
function renderMenu() {
  const list = FOOD_ITEMS.filter((f) =>
    (activeCategory === "All" || f.category === activeCategory) &&
    f.name.toLowerCase().includes(searchText.trim().toLowerCase()));
  foodGrid.innerHTML = list.map((f) => `
    <article class="food-card">
      <img src="${f.image}" alt="${f.name}" loading="lazy">
      <div class="food-body">
        <h3>${f.name}</h3>
        <span class="tag">${f.category}</span>
        <p class="desc">${f.description}</p>
        <div class="food-foot">
          <span class="price">${money(f.price)}</span>
          <button class="add-btn" data-add="${f.id}">Add +</button>
        </div>
      </div>
    </article>`).join("");
  noResults.classList.toggle("hidden", list.length > 0);
}

// ===== Cart operations =====
function addToCart(id) { cart[id] = (cart[id] || 0) + 1; updateCart(); }
function changeQty(id, delta) {
  cart[id] = (cart[id] || 0) + delta;
  if (cart[id] <= 0) delete cart[id];
  updateCart();
}
function removeFromCart(id) { delete cart[id]; updateCart(); }
function clearCart() { cart = {}; updateCart(); }

function updateCart() {
  saveCart();
  const ids = Object.keys(cart);
  const isEmpty = ids.length === 0;
  emptyCart.classList.toggle("hidden", !isEmpty);
  orderSummary.classList.toggle("hidden", isEmpty);
  orderForm.classList.toggle("hidden", isEmpty);

  let subtotal = 0, count = 0, itemsHtml = "", rowsHtml = "";
  ids.forEach((id) => {
    const f = findItem(id), qty = cart[id], line = f.price * qty;
    subtotal += line; count += qty;
    itemsHtml += `
      <div class="cart-item">
        <img src="${f.image}" alt="${f.name}">
        <div class="ci-info">
          <strong>${f.name}</strong><span>${money(f.price)} each</span>
          <div class="qty">
            <button data-dec="${id}" aria-label="Decrease quantity">−</button>
            <span>${qty}</span>
            <button data-inc="${id}" aria-label="Increase quantity">+</button>
          </div>
        </div>
        <div class="ci-sub">${money(line)}</div>
        <button class="remove-btn" data-remove="${id}" aria-label="Remove ${f.name}">🗑</button>
      </div>`;
    rowsHtml += `<tr><td>${f.name}</td><td>${qty} × ${money(f.price)}</td><td>${money(line)}</td></tr>`;
  });
  const gst = subtotal * GST_RATE;
  cartItemsEl.innerHTML = itemsHtml;
  $("summaryBody").innerHTML = rowsHtml;
  $("subTotal").textContent = money(subtotal);
  $("gstAmount").textContent = money(gst);
  $("grandTotal").textContent = money(subtotal + gst);
  cartCount.textContent = count;
}

// ===== Validation =====
function setError(fieldId, errId, msg) {
  $(errId).textContent = msg;
  $(fieldId).classList.toggle("invalid", !!msg);
  return !msg;
}
function validateForm() {
  const name = $("custName").value.trim(), phone = $("custPhone").value.trim();
  const email = $("custEmail").value.trim(), addr = $("custAddress").value.trim();
  const pay = $("custPayment").value;
  const results = [
    setError("custName", "errName", !name ? "Name is required." : !/^[A-Za-z .]{3,}$/.test(name) ? "Enter a valid name (letters only, min 3)." : ""),
    setError("custPhone", "errPhone", !phone ? "Phone number is required." : !/^[6-9]\d{9}$/.test(phone) ? "Enter a valid 10-digit mobile number." : ""),
    setError("custEmail", "errEmail", !email ? "Email is required." : !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) ? "Enter a valid email address." : ""),
    setError("custAddress", "errAddress", !addr ? "Address is required." : addr.length < 10 ? "Address must be at least 10 characters." : ""),
    setError("custPayment", "errPayment", !pay ? "Select a payment method." : "")
  ];
  return results.every(Boolean);
}

// ===== Order submission =====
function submitOrder(e) {
  e.preventDefault();
  if (Object.keys(cart).length === 0) return;
  if (!validateForm()) return;
  const total = $("grandTotal").textContent;
  const orderId = "TB" + Date.now().toString().slice(-6);
  $("successText").textContent =
    `Thank you, ${$("custName").value.trim()}! Your order ${orderId} of ${total} will be delivered soon via ${$("custPayment").value}.`;
  $("successModal").classList.remove("hidden");
  orderForm.reset();
  clearCart();
  cartPanel.classList.remove("open");
}

// ===== Event listeners =====
filters.addEventListener("click", (e) => {
  const b = e.target.closest("[data-cat]");
  if (!b) return;
  activeCategory = b.dataset.cat;
  renderFilters(); renderMenu();
});
$("searchInput").addEventListener("input", (e) => { searchText = e.target.value; renderMenu(); });
foodGrid.addEventListener("click", (e) => {
  const b = e.target.closest("[data-add]");
  if (b) addToCart(b.dataset.add);
});
cartItemsEl.addEventListener("click", (e) => {
  const t = e.target.closest("button");
  if (!t) return;
  if (t.dataset.inc) changeQty(t.dataset.inc, 1);
  else if (t.dataset.dec) changeQty(t.dataset.dec, -1);
  else if (t.dataset.remove) removeFromCart(t.dataset.remove);
});
$("clearCart").addEventListener("click", clearCart);
orderForm.addEventListener("submit", submitOrder);
$("cartToggle").addEventListener("click", () => cartPanel.classList.add("open"));
$("cartClose").addEventListener("click", () => cartPanel.classList.remove("open"));
$("modalClose").addEventListener("click", () => $("successModal").classList.add("hidden"));

// ===== Init =====
renderFilters();
renderMenu();
updateCart();   // restores saved cart from Local Storage
