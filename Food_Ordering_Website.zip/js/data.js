// Menu data: each item has id, name, description, category, price (INR) and image.
const FOOD_ITEMS = [
  { id: 1,  name: "Masala Dosa",          category: "Starters",    price: 80,  image: "images/masala-dosa.svg",          description: "Crispy rice crepe filled with spiced potato masala." },
  { id: 2,  name: "Paneer Tikka",         category: "Starters",    price: 180, image: "images/paneer-tikka.svg",         description: "Grilled cottage cheese cubes marinated in spices." },
  { id: 3,  name: "Veg Spring Rolls",     category: "Starters",    price: 120, image: "images/veg-spring-rolls.svg",     description: "Golden rolls stuffed with crunchy vegetables." },
  { id: 4,  name: "Chicken 65",           category: "Starters",    price: 190, image: "images/chicken-65.svg",           description: "Spicy deep-fried chicken bites with curry leaves." },
  { id: 5,  name: "French Fries",         category: "Starters",    price: 90,  image: "images/french-fries.svg",         description: "Crispy salted potato fries served hot." },
  { id: 6,  name: "Butter Chicken",       category: "Main Course", price: 260, image: "images/butter-chicken.svg",       description: "Tender chicken in a creamy tomato-butter gravy." },
  { id: 7,  name: "Paneer Butter Masala", category: "Main Course", price: 220, image: "images/paneer-butter-masala.svg", description: "Soft paneer simmered in rich buttery tomato gravy." },
  { id: 8,  name: "Veg Fried Rice",       category: "Main Course", price: 140, image: "images/veg-fried-rice.svg",       description: "Wok-tossed rice with fresh vegetables and sauces." },
  { id: 9,  name: "Margherita Pizza",     category: "Main Course", price: 249, image: "images/margherita-pizza.svg",     description: "Classic pizza with mozzarella, tomato and basil." },
  { id: 10, name: "Chicken Biryani",      category: "Biryani",     price: 240, image: "images/chicken-biryani.svg",      description: "Aromatic basmati rice layered with spiced chicken." },
  { id: 11, name: "Veg Biryani",          category: "Biryani",     price: 170, image: "images/veg-biryani.svg",          description: "Fragrant rice cooked with vegetables and herbs." },
  { id: 12, name: "Gulab Jamun",          category: "Desserts",    price: 60,  image: "images/gulab-jamun.svg",          description: "Soft milk dumplings soaked in sugar syrup." },
  { id: 13, name: "Ice Cream Sundae",     category: "Desserts",    price: 110, image: "images/ice-cream-sundae.svg",     description: "Vanilla ice cream with chocolate sauce and nuts." },
  { id: 14, name: "Mango Lassi",          category: "Beverages",   price: 70,  image: "images/mango-lassi.svg",          description: "Chilled yogurt drink blended with ripe mango." },
  { id: 15, name: "Cold Coffee",          category: "Beverages",   price: 90,  image: "images/cold-coffee.svg",          description: "Creamy iced coffee topped with chocolate." },
  { id: 16, name: "Fresh Lime Soda",      category: "Beverages",   price: 50,  image: "images/fresh-lime-soda.svg",      description: "Refreshing lime soda, sweet or salted." }
];
